function m = next(k)
% m = next(k)
% next power of two
% m = 2^ceil(log2(k));

% Ivan Selesnick
% November 2010

m = 2.^ceil(log2(k));


